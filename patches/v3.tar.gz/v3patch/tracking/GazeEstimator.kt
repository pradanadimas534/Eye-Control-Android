package com.dimas.eyecontrol.tracking

import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import com.google.mediapipe.tasks.vision.facelandmarker.FaceLandmarkerResult
import kotlin.math.abs
import kotlin.math.hypot

class GazeEstimator {
    private var smoothX = 0f
    private var smoothY = 0f
    private var initialized = false
    private var blinkStartedAt = 0L
    private var blinkWasClosed = false
    private var longBlinkEventId = 0L

    data class Estimate(
        val rawX: Float,
        val rawY: Float,
        val blinkScore: Float,
        val longBlinkEventId: Long
    )

    fun estimate(result: FaceLandmarkerResult, nowMs: Long): Estimate? {
        val blendshapes = result.faceBlendshapes()
        if (!blendshapes.isPresent) return null
        val shapes = blendshapes.get().firstOrNull() ?: return null
        val scores = shapes.associate { it.categoryName() to it.score() }
        fun score(name: String): Float = scores[name] ?: 0f

        val blink = (score("eyeBlinkLeft") + score("eyeBlinkRight")) * 0.5f

        val lookLeft = (score("eyeLookOutLeft") + score("eyeLookInRight")) * 0.5f
        val lookRight = (score("eyeLookInLeft") + score("eyeLookOutRight")) * 0.5f
        val lookUp = (score("eyeLookUpLeft") + score("eyeLookUpRight")) * 0.5f
        val lookDown = (score("eyeLookDownLeft") + score("eyeLookDownRight")) * 0.5f

        val blendX = ((lookRight - lookLeft) * 1.70f).coerceIn(-1.20f, 1.20f)
        val blendY = ((lookDown - lookUp) * 1.75f).coerceIn(-1.20f, 1.20f)

        val face = result.faceLandmarks().firstOrNull()
        var rawX = blendX
        var rawY = blendY

        if (face != null) {
            irisSignal(face)?.let { (irisX, irisY) ->
                // Horizontal iris position is generally strong on selfie cameras.
                // Vertical iris position is much more sensitive to eyelid shape, so
                // Face Blendshapes carry more weight on Y to prevent the cursor from
                // permanently collapsing to the bottom edge.
                rawX = irisX * 0.72f + blendX * 0.28f
                rawY = irisY * 0.28f + blendY * 0.72f
            }
        }

        rawX = rawX.coerceIn(-1.5f, 1.5f)
        rawY = rawY.coerceIn(-1.5f, 1.5f)

        if (blink < 0.56f || !initialized) {
            if (!initialized) {
                smoothX = rawX
                smoothY = rawY
                initialized = true
            } else {
                val movement = hypot(
                    (rawX - smoothX).toDouble(),
                    (rawY - smoothY).toDouble()
                ).toFloat()
                val alpha = when {
                    movement > 0.42f -> 0.48f
                    movement > 0.18f -> 0.34f
                    else -> 0.16f
                }
                smoothX += alpha * (rawX - smoothX)
                smoothY += alpha * (rawY - smoothY)
            }
        }

        val closed = blink > 0.68f
        if (closed && !blinkWasClosed) {
            blinkStartedAt = nowMs
            blinkWasClosed = true
        } else if (!closed && blinkWasClosed) {
            val duration = nowMs - blinkStartedAt
            if (duration in 550..1600) longBlinkEventId++
            blinkWasClosed = false
        }

        return Estimate(smoothX, smoothY, blink, longBlinkEventId)
    }

    private fun irisSignal(face: List<NormalizedLandmark>): Pair<Float, Float>? {
        if (face.size < 478) return null

        val right = normalizedEye(
            iris = face[468],
            cornerA = face[33],
            cornerB = face[133],
            top = face[159],
            bottom = face[145]
        ) ?: return null

        val left = normalizedEye(
            iris = face[473],
            cornerA = face[362],
            cornerB = face[263],
            top = face[386],
            bottom = face[374]
        ) ?: return null

        val imageX = (((right.first + left.first) * 0.5f) - 0.5f) * 3.0f
        val userX = -imageX
        val y = (((right.second + left.second) * 0.5f) - 0.5f) * 3.0f
        return userX.coerceIn(-1.5f, 1.5f) to y.coerceIn(-1.5f, 1.5f)
    }

    private fun normalizedEye(
        iris: NormalizedLandmark,
        cornerA: NormalizedLandmark,
        cornerB: NormalizedLandmark,
        top: NormalizedLandmark,
        bottom: NormalizedLandmark
    ): Pair<Float, Float>? {
        val minX = minOf(cornerA.x(), cornerB.x())
        val maxX = maxOf(cornerA.x(), cornerB.x())
        val minY = minOf(top.y(), bottom.y())
        val maxY = maxOf(top.y(), bottom.y())
        val width = maxX - minX
        val height = maxY - minY
        if (abs(width) < 1e-5f || abs(height) < 1e-5f) return null
        return ((iris.x() - minX) / width).coerceIn(0f, 1f) to
            ((iris.y() - minY) / height).coerceIn(0f, 1f)
    }
}
