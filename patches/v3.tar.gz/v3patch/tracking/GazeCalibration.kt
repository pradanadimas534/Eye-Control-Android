package com.dimas.eyecontrol.tracking

import android.content.Context
import kotlin.math.abs
import kotlin.math.sign

/**
 * Calibration v3 uses three anchors per axis instead of one global affine line.
 * This is much more stable for phone selfie cameras because eye movement is not
 * perfectly linear and the neutral iris position is rarely exactly 0.5.
 */
object GazeCalibration {
    private const val PREFS = "eye_control_prefs"
    private const val CALIBRATED = "calibrated"
    private const val CALIBRATION_VERSION_KEY = "calibration_version"
    private const val CALIBRATION_VERSION = 3

    private const val LEFT_X = "v3_left_x"
    private const val CENTER_X = "v3_center_x"
    private const val RIGHT_X = "v3_right_x"
    private const val TOP_Y = "v3_top_y"
    private const val CENTER_Y = "v3_center_y"
    private const val BOTTOM_Y = "v3_bottom_y"

    @Volatile private var loaded = false
    @Volatile private var calibrated = false

    @Volatile private var leftX = -0.35f
    @Volatile private var centerX = 0f
    @Volatile private var rightX = 0.35f
    @Volatile private var topY = -0.30f
    @Volatile private var centerY = 0f
    @Volatile private var bottomY = 0.30f

    fun ensureLoaded(context: Context) {
        if (loaded) return
        synchronized(this) {
            if (loaded) return
            val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val version = p.getInt(CALIBRATION_VERSION_KEY, 0)
            if (version == CALIBRATION_VERSION) {
                calibrated = p.getBoolean(CALIBRATED, false)
                leftX = p.getFloat(LEFT_X, leftX)
                centerX = p.getFloat(CENTER_X, centerX)
                rightX = p.getFloat(RIGHT_X, rightX)
                topY = p.getFloat(TOP_Y, topY)
                centerY = p.getFloat(CENTER_Y, centerY)
                bottomY = p.getFloat(BOTTOM_Y, bottomY)
            } else {
                calibrated = false
            }
            loaded = true
        }
    }

    fun map(context: Context, rawX: Float, rawY: Float): Pair<Float, Float> {
        ensureLoaded(context)
        if (!calibrated) return 0.5f to 0.5f
        return axisMap(rawX, leftX, centerX, rightX) to
            axisMap(rawY, topY, centerY, bottomY)
    }

    /**
     * low/center/high are physical samples corresponding to the low screen side,
     * center and high screen side. Their numeric order may be reversed, so the
     * function derives orientation from the anchors instead of assuming a sign.
     *
     * Calibration targets map to roughly 10% / 50% / 90% of the display. Looking
     * beyond a calibration target can still reach the extreme edge, but ordinary
     * gaze will not accidentally sit in the system gesture zones.
     */
    private fun axisMap(value: Float, low: Float, center: Float, high: Float): Float {
        val direction = sign(high - low).takeIf { it != 0f } ?: 1f
        val d = (value - center) * direction
        val lowSpan = abs(center - low).coerceAtLeast(0.035f)
        val highSpan = abs(high - center).coerceAtLeast(0.035f)

        val ratio = if (d < 0f) d / lowSpan else d / highSpan
        return (0.5f + 0.40f * ratio.coerceIn(-1.20f, 1.20f)).coerceIn(0.02f, 0.98f)
    }

    fun saveAnchors(
        context: Context,
        left: Float,
        centerHorizontal: Float,
        right: Float,
        top: Float,
        centerVertical: Float,
        bottom: Float
    ): Boolean {
        val all = floatArrayOf(left, centerHorizontal, right, top, centerVertical, bottom)
        if (all.any { !it.isFinite() }) return false
        if (!axisLooksValid(left, centerHorizontal, right)) return false
        if (!axisLooksValid(top, centerVertical, bottom)) return false

        leftX = left
        centerX = centerHorizontal
        rightX = right
        topY = top
        centerY = centerVertical
        bottomY = bottom
        calibrated = true
        loaded = true

        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putInt(CALIBRATION_VERSION_KEY, CALIBRATION_VERSION)
            .putBoolean(CALIBRATED, true)
            .putFloat(LEFT_X, leftX)
            .putFloat(CENTER_X, centerX)
            .putFloat(RIGHT_X, rightX)
            .putFloat(TOP_Y, topY)
            .putFloat(CENTER_Y, centerY)
            .putFloat(BOTTOM_Y, bottomY)
            .apply()
        return true
    }

    private fun axisLooksValid(low: Float, center: Float, high: Float): Boolean {
        val a = low - center
        val b = high - center
        // We need visible movement to both sides of center, not merely a large noisy range.
        if (abs(a) < 0.025f || abs(b) < 0.025f) return false
        if (a * b >= 0f) return false
        return abs(high - low) >= 0.07f
    }

    fun isCalibrated(context: Context): Boolean {
        ensureLoaded(context)
        return calibrated
    }

    fun invalidate(context: Context) {
        calibrated = false
        loaded = true
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putInt(CALIBRATION_VERSION_KEY, CALIBRATION_VERSION)
            .putBoolean(CALIBRATED, false)
            .apply()
    }
}
