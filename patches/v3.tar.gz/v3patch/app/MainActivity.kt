package com.dimas.eyecontrol

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.dimas.eyecontrol.calibration.CalibrationActivity
import com.dimas.eyecontrol.databinding.ActivityMainBinding
import com.dimas.eyecontrol.tracking.EyeControlBus
import com.dimas.eyecontrol.tracking.EyeTrackingService
import com.dimas.eyecontrol.tracking.GazeCalibration
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    private val cameraPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            Toast.makeText(
                this,
                if (granted) "Kamera diizinkan" else "Izin kamera dibutuhkan untuk membaca arah mata",
                Toast.LENGTH_SHORT
            ).show()
            renderStatus()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        binding.switchBlinkClick.isChecked = prefs.getBoolean(KEY_BLINK_CLICK, false)
        binding.switchBlinkClick.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(KEY_BLINK_CLICK, checked).apply()
        }

        binding.btnCameraPermission.setOnClickListener {
            if (hasCameraPermission()) {
                Toast.makeText(this, "Izin kamera sudah aktif", Toast.LENGTH_SHORT).show()
            } else {
                cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
            }
        }

        binding.btnAccessibility.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        binding.btnStart.setOnClickListener {
            if (startEyeControl() && !GazeCalibration.isCalibrated(this)) {
                Toast.makeText(this, "Kalibrasi wajib untuk tracker v3", Toast.LENGTH_LONG).show()
                startActivity(Intent(this, CalibrationActivity::class.java))
            }
        }

        binding.btnCalibrate.setOnClickListener {
            if (!hasCameraPermission()) {
                cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                Toast.makeText(this, "Izinkan kamera dulu, lalu tekan Kalibrasi lagi", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            GazeCalibration.invalidate(this)
            startEyeControl()
            startActivity(Intent(this, CalibrationActivity::class.java))
        }

        binding.btnStop.setOnClickListener {
            startService(Intent(this, EyeTrackingService::class.java).setAction(EyeTrackingService.ACTION_STOP))
        }

        lifecycleScope.launch {
            EyeControlBus.sample.collectLatest { renderStatus() }
        }
    }

    override fun onResume() {
        super.onResume()
        renderStatus()
    }

    private fun startEyeControl(): Boolean {
        if (!hasCameraPermission()) {
            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
            return false
        }
        val intent = Intent(this, EyeTrackingService::class.java).setAction(EyeTrackingService.ACTION_START)
        ContextCompat.startForegroundService(this, intent)
        Toast.makeText(this, "Eye Control dimulai", Toast.LENGTH_SHORT).show()
        return true
    }

    private fun hasCameraPermission(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    private fun renderStatus() {
        val sample = EyeControlBus.sample.value
        val camera = if (hasCameraPermission()) "kamera ✓" else "kamera ✗"
        val tracking = if (sample.tracking) "tracking aktif" else "tracking mati"
        val face = if (sample.faceDetected) "wajah terdeteksi" else "wajah belum terdeteksi"
        val calibration = if (GazeCalibration.isCalibrated(this)) "kalibrasi ✓" else "kalibrasi wajib"
        binding.tvStatus.text = "Status: $camera • $tracking • $face • $calibration"
    }

    companion object {
        const val PREFS = "eye_control_prefs"
        const val KEY_BLINK_CLICK = "blink_click"
    }
}
