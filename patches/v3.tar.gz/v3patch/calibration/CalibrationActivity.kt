package com.dimas.eyecontrol.calibration

import android.os.Bundle
import android.os.SystemClock
import android.view.View
import android.view.WindowInsets
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.dimas.eyecontrol.tracking.EyeControlBus
import com.dimas.eyecontrol.tracking.GazeCalibration
import kotlinx.coroutines.launch

class CalibrationActivity : AppCompatActivity() {
    private lateinit var calibrationView: CalibrationView

    // Start at center, then cardinal directions, then corners. This gives the user
    // an intuitive neutral reference before asking for large eye movements.
    private val targets = listOf(
        0.50f to 0.50f,
        0.15f to 0.50f,
        0.85f to 0.50f,
        0.50f to 0.15f,
        0.50f to 0.85f,
        0.15f to 0.15f,
        0.85f to 0.15f,
        0.15f to 0.85f,
        0.85f to 0.85f
    )

    private data class CalPoint(
        val rawX: Float,
        val rawY: Float,
        val targetX: Float,
        val targetY: Float
    )

    private val points = mutableListOf<CalPoint>()
    private var targetIndex = 0
    private var phaseStartedAt = 0L
    private val samples = mutableListOf<Pair<Float, Float>>()
    private var completed = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        EyeControlBus.setCalibrationActive(true)
        calibrationView = CalibrationView(this)
        setContentView(calibrationView)
        hideSystemUi()
        moveToTarget(0)

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                EyeControlBus.sample.collect { sample ->
                    if (!sample.tracking) {
                        calibrationView.subMessage = "Tracking belum aktif. Kembali dan tekan Mulai Eye Control."
                        calibrationView.invalidate()
                        return@collect
                    }
                    if (!sample.faceDetected) {
                        calibrationView.subMessage = "Wajah belum terdeteksi. Hadapkan wajah ke kamera."
                        calibrationView.invalidate()
                        return@collect
                    }
                    if (sample.blinkScore > 0.44f) return@collect
                    processSample(sample.rawX, sample.rawY)
                }
            }
        }
    }

    private fun moveToTarget(index: Int) {
        targetIndex = index
        val target = targets[index]
        calibrationView.targetXNorm = target.first
        calibrationView.targetYNorm = target.second
        calibrationView.message = "Kalibrasi ${index + 1}/${targets.size}"
        calibrationView.subMessage = if (index == 0) {
            "Tatap tengah. Kepala dan HP tetap diam."
        } else {
            "Gerakkan mata saja ke titik. Jangan ikut memutar kepala."
        }
        calibrationView.invalidate()
        samples.clear()
        phaseStartedAt = SystemClock.uptimeMillis()
    }

    private fun processSample(rawX: Float, rawY: Float) {
        if (completed) return
        val now = SystemClock.uptimeMillis()
        val elapsed = now - phaseStartedAt

        // Longer settle time avoids learning the saccade used to reach the next dot.
        if (elapsed < 900L) return
        if (elapsed <= 2100L) {
            samples += rawX to rawY
            calibrationView.subMessage = "Tahan pandangan…"
            calibrationView.invalidate()
            return
        }

        if (samples.size < 10) {
            phaseStartedAt = now - 900L
            samples.clear()
            calibrationView.subMessage = "Ulangi titik ini — pandangan belum stabil"
            calibrationView.invalidate()
            return
        }

        // Trim the outer quartiles around the median so one short glance does not
        // drag an entire anchor toward the screen edge.
        val rawXStable = trimmedMedian(samples.map { it.first })
        val rawYStable = trimmedMedian(samples.map { it.second })
        val target = targets[targetIndex]
        points += CalPoint(rawXStable, rawYStable, target.first, target.second)

        if (targetIndex == targets.lastIndex) finishCalibration()
        else moveToTarget(targetIndex + 1)
    }

    private fun finishCalibration() {
        if (completed) return
        completed = true

        fun xFor(predicate: (Float) -> Boolean): Float =
            median(points.filter { predicate(it.targetX) }.map { it.rawX })

        fun yFor(predicate: (Float) -> Boolean): Float =
            median(points.filter { predicate(it.targetY) }.map { it.rawY })

        val left = xFor { it < 0.20f }
        val centerX = xFor { it in 0.45f..0.55f }
        val right = xFor { it > 0.80f }
        val top = yFor { it < 0.20f }
        val centerY = yFor { it in 0.45f..0.55f }
        val bottom = yFor { it > 0.80f }

        val ok = GazeCalibration.saveAnchors(
            this,
            left = left,
            centerHorizontal = centerX,
            right = right,
            top = top,
            centerVertical = centerY,
            bottom = bottom
        )

        Toast.makeText(
            this,
            if (ok) {
                "Kalibrasi v3 selesai — kiri/kanan dan atas/bawah sudah dipetakan terpisah"
            } else {
                "Kalibrasi gagal: gerakan mata belum terbaca jelas. Dekatkan HP sedikit lalu ulangi."
            },
            Toast.LENGTH_LONG
        ).show()
        finish()
    }

    private fun trimmedMedian(values: List<Float>): Float {
        if (values.isEmpty()) return 0f
        val sorted = values.sorted()
        val trim = (sorted.size * 0.20f).toInt().coerceAtMost((sorted.size - 1) / 2)
        return median(sorted.subList(trim, sorted.size - trim))
    }

    private fun median(values: List<Float>): Float {
        if (values.isEmpty()) return 0f
        val sorted = values.sorted()
        val mid = sorted.size / 2
        return if (sorted.size % 2 == 0) {
            (sorted[mid - 1] + sorted[mid]) * 0.5f
        } else {
            sorted[mid]
        }
    }

    override fun onStop() {
        EyeControlBus.setCalibrationActive(false)
        super.onStop()
    }

    private fun hideSystemUi() {
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            window.insetsController?.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                )
        }
    }
}
